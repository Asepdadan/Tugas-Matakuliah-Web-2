<?php
include "config.php";

session_start();

$idbiodata = $_POST['idbiodata'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$nohp = $_POST['nohp'];


$_SESSION["idbiodata"] = $_POST['idbiodata'];




$query = "INSERT INTO biodata VALUES('$idbiodata','$nama','$alamat','$nohp')";
$query1 = mysql_query($query);
if($query1){
	
header("location:pendidikan.php");
}else{
	header("location:index.php");
}



/*$idbiodata = $_POST['idbiodata'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$nohp = $_POST['nohp'];

if(isset($_POST))
{
	$query = "INSERT INTO biodata VALUES('$idbiodata','$nama','$alamat','$nohp')";
$query1 = mysql_query($query);
header("location:pendidikan.php");


}

/*$pendidikan = array(
	'sd' => $_POST['sd'],
	'smp' => $_POST['smp'],
	'sma' => $_POST['sma']

	);

print_r($biodata);
print_r($pendidikan);


/*
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$nohp = $_POST['nohp'];
$sd = $_POST['sd'];
$smp = $_POST['smp'];
$sma = $_POST['sma'];

$query = "INSERT INTO biodata VALUES('','$nama','$alamat','$nohp')";
$query1 = mysql_query($query);

if($query1)
{
	header("location:pendidikan.php");
}


$query = "INSERT INTO biodata VALUES('','$sd','$smp','$sma')";
$query2 = mysql_query($query);
*/
?>