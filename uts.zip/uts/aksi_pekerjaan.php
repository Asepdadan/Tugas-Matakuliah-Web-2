<?php
include "config.php";
session_start();




$idbiodata = $_SESSION['idbiodata'];
$pekerjaan = $_POST['pekerjaan'];

$query = "INSERT INTO  pekerjaan VALUES('$idbiodata','$pekerjaan')";
$query1= mysql_query($query);

if($query1){
	header("location:history.php");
	
}else{
	header("location:pekerjaan.php");
}
session_destroy($idbiodata);

?>