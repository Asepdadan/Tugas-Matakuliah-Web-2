<?php
include "config.php";
session_start();


$idbiodata = $_SESSION['idbiodata'];
$sd = $_POST['sd'];
$smp = $_POST['smp'];
$sma = $_POST['sma'];


$query = "INSERT INTO pendidikan VALUES('$idbiodata','$sd','$smp','$sma')";
$query1 = mysql_query($query);

if($query1){
header("location:pekerjaan.php");
}else{
	header("location:pendidikan.php");
}





?>