<?php
error_reporting(0);
$h = "localhost";
$u = "root";
$p = "";

$con = mysql_connect($h,$u,$p)or die ('Error connecting to mysql');
$db = "db_uts";
$dbs = mysql_select_db($db);





?>