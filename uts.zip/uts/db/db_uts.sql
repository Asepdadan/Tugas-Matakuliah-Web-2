-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 11, 2015 at 10:26 
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_uts`
--

-- --------------------------------------------------------

--
-- Table structure for table `biodata`
--

CREATE TABLE `biodata` (
  `idbiodata` varchar(8) COLLATE ascii_bin NOT NULL,
  `nama` varchar(30) COLLATE ascii_bin NOT NULL,
  `alamat` varchar(150) COLLATE ascii_bin NOT NULL,
  `nohp` varchar(14) COLLATE ascii_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_bin;

--
-- Dumping data for table `biodata`
--

INSERT INTO `biodata` (`idbiodata`, `nama`, `alamat`, `nohp`) VALUES
('13402351', 'Asep dadan', 'Garut', '08997344989'),
('13402352', 'asdan', 'garut', '08997344989'),
('13402355', 'asdan', 'garut', '08997344989');

-- --------------------------------------------------------

--
-- Table structure for table `pekerjaan`
--

CREATE TABLE `pekerjaan` (
  `idbiodata` varchar(8) NOT NULL,
  `pekerjaan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pekerjaan`
--

INSERT INTO `pekerjaan` (`idbiodata`, `pekerjaan`) VALUES
('13402351', 'Mahasiswa'),
('13402352', ''),
('13402355', '');

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE `pendidikan` (
  `idbiodata` varchar(8) NOT NULL,
  `sd` varchar(50) NOT NULL,
  `smp` varchar(50) NOT NULL,
  `sma` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendidikan`
--

INSERT INTO `pendidikan` (`idbiodata`, `sd`, `smp`, `sma`) VALUES
('13402351', 'SDn Cikembulan 03', 'Mts Muhammadiyah Cisaat', 'SMK Muhammadiyah Kadungora'),
('13402352', '', '', ''),
('13402355', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `biodata`
--
ALTER TABLE `biodata`
  ADD PRIMARY KEY (`idbiodata`);

--
-- Indexes for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  ADD PRIMARY KEY (`idbiodata`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`idbiodata`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
