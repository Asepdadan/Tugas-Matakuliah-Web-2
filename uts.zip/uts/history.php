<?php
include "config.php";
session_start();
session_destroy();

$query ="SELECT `biodata`.`idbiodata`,`biodata`.`nama`,`pekerjaan`.`pekerjaan`,`pendidikan`.`sd`,`pendidikan`.`smp`,`pendidikan`.`sma`,`biodata`.`nohp` FROM biodata,pendidikan,pekerjaan WHERE biodata.`idbiodata` = pendidikan.`idbiodata` AND biodata.`idbiodata` = pekerjaan.`idbiodata`";
$result = mysql_query($query);


?>

<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Title Page</title>

		<!-- style CSS -->
		<link href="assets/css/style.css" rel="stylesheet">

	

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	

	
	<body>
	<div class="menu">
	<ul>
		<li><a href="index.php">biodata</a></li>
		<li><a href="pendidikan.php">pendidikan</a></li>
		<li><a href="pekerjaan.php">pekerjaan</a></li>
		<li><a href="history.php">history</a></li>
		<li><a href="history.php" style="float:right;">login</a></li>
		<li><a href="history.php"style="float:right;" >sign up</a></li>
	</ul>
	</div>

<div class="bawah">
	

		<div class="sidebar">
		<ul>
		<li><a href="index.php">biodata</a></li>
		<li><a href="pendidikan.php">pendidikan</a></li>
		<li><a href="pekerjaan.php">pekerjaan</a></li>
		<li><a href="history.php" class="active">history</a></li>
		</ul>	




		</div>


		<div class="content">
		
		<table cellpadding="3" cellspacing="3" border="1">
			<thead>
				<tr>
					<th>No </th>
					<th>Id Biodata</th>
					<th>Nama</th>
					<th>No Handphone</th>
					<th>Pendidikan SD</th>
					<th>Pendidikan SMP</th>
					<th>Pendidikan SMA</th>
					<th>Pekerjaan</th>
				</tr>
			</thead>
			<tbody>
			<?php 
			$no = 1;
			while ($row = mysql_fetch_assoc($result)) {
			
			?>
				<tr>
					<td><?php echo $no++ ?></td>
					<td><?php echo $row['idbiodata']; ?></td>
					<td><?php echo $row['nama']; ?></td>
					<td><?php echo $row['nohp']; ?></td>
					<td><?php echo $row['sd']; ?></td>
					<td><?php echo $row['smp']; ?></td>
					<td><?php echo $row['sma']; ?></td>
					<td><?php echo $row['pekerjaan']; ?></td>
				</tr>
			<?php } ?>

			</tbody>
		</table>


		</div>



</div>


<!--<div class="footer">

&copy; copyright Asep Dadan

</div>
	-->

</body>
</html>

