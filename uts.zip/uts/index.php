<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Title Page</title>

		
		<link href="assets/css/style.css" rel="stylesheet">
		<script src="assets/js/jquery-1.9.1.min.js"></script>


		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<script type="text/javascript">
		$(document).ready(function() {
		$("#idbiodata").focus();
		
		$("#idbiodata").keypress(function (data)
		{
		// kalau data bukan berupa angka, tampilkan pesan error
		if(data.which!=8 && data.which!=0 &&
		(data.which<48 || data.which>57))
		{
		$("#pesan").html("Hanya bisa di isikan angka").show().fadeOut("slow");
		return false;
		}
		});

		$('#karakter').keyup(function() {
		var len = this.value.length;
		if (len >= 150) {
		this.value = this.value.substring(0, 150);
		}
		$('#hitung').text(150 - len);
		});
		$(':input:not([type="submit"])').each(function() {
$(this).focus(function() {
$(this).parent().addClass('hilite');
}).blur(function() {
$(this). parent().removeClass('hilite');});
});

		});

	</script>
	
	<body>
	<div class="menu">
	<ul>
		<li><a href="index.php">biodata</a></li>
		<li><a href="pendidikan.php">pendidikan</a></li>
		<li><a href="pekerjaan.php">pekerjaan</a></li>
		<li><a href="history.php">history</a></li>
		<li><a href="history.php" style="float:right;">login</a></li>
		<li><a href="history.php"style="float:right;" >sign up</a></li>
	</ul>
	</div>

<div class="bawah">
	

		<div class="sidebar">
		<ul>
		<li><a href="index.php">biodata</a></li>
		<li><a href="pendidikan.php">pendidikan</a></li>
		<li><a href="pekerjaan.php">pekerjaan</a></li>
		<li><a href="history.php">history</a></li>
		</ul>	




		</div>


		<div class="content">
		
			<div class="kotak">
	
			<h3>Form Input Biodata</h3>

					<form action="aksi.php" method="POST" class="form-horizontal" role="form">
							
								<h4 id="pesan"></h4>
								<input type="text" name="idbiodata" placeholder="isi terdahulu id jika akan melanjutkan ke page selanjutnya" required maxlength="8" size="10" id="idbiodata">
								
								<input type="text" name="nama" required placeholder="nama" maxlength="35">
								
								<textarea name="alamat" required placeholder="alamat" maxlength="150" id="karakter"></textarea>
								<p id="hitung" style="font-size:8pt; text-align:center;">150 Tersisa Karakter</p> 
								<input type="text" name="nohp" required placeholder="no handphone" maxlength="13">			
								<button type="submit" class="btn btn-primary" name="biodata">Simpan</button>
					</form>

					

			</div>



		</div>



</div>


<!--<div class="footer">

&copy; copyright Asep Dadan

</div>
	-->

</body>
</html>