<?php
session_start();

if(!$_SESSION['idbiodata']){
header("location:index.php");
}


?>


<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Title Page</title>

		<!-- Bootstrap CSS -->
		<link href="assets/css/style.css" rel="stylesheet">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
	<div class="menu">
		<ul>
		<li><a href="index.php">biodata</a></li>
		<li><a href="pendidikan.php">pendidikan</a></li>
		<li><a href="pekerjaan.php">pekerjaan</a></li>
		<li><a href="history.php">history</a></li>
		<li><a href="history.php" style="float:right;">login</a></li>
		<li><a href="history.php"style="float:right;" >sign up</a></li>
	</ul>
	
	</div>
<div class="bawah">
	
	<div class="sidebar">

	</div>


	<div class="content">
		<div class="kotak">
		<h1 class="text-center">Hello World <?php echo $_SESSION['idbiodata']; ?></h1>
		<form action="aksi_pekerjaan.php" method="post">
		<input type="text" name="idbiodata" hidden>
		<input type="text" name="pekerjaan" placeholder="Isi Data Pekerjaan" maxlength="25">
		<input type="submit" name="simpan" value="simpan">
		</form>
		</div>

	</div>


</div>

		





	

	</body>
</html>